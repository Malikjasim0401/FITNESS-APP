# Action Recognition and Image Captioning System

## 🎯 Project Overview

This project implements an **Action Recognition and Image Captioning System** using **CNN (Convolutional Neural Networks)** and **LSTM (Long Short-Term Memory)** models. The system analyzes images to:

- Recognize human actions/activities
- Generate descriptive captions

### Features

- 🎬 **Action Recognition**: Identifies 6 different human activities (Walking, Walking Upstairs, Walking Downstairs, Sitting, Standing, Laying)
- 💬 **Image Captioning**: Generates natural language descriptions of images
- 🌐 **REST API**: Flask-based backend with RESTful API endpoints
- 💻 **Modern Frontend**: Clean, responsive web interface
- 🚀 **Deep Learning**: Uses pre-trained models (MobileNetV2, InceptionV3) with custom layers

## 📁 Project Structure

```
assignment-dl/
├── backend/
│   ├── app.py                    # Flask API server
│   ├── action_recognition.py     # Action recognition model (CNN+LSTM)
│   ├── image_captioning.py       # Image captioning model (CNN+LSTM)
│   └── requirements.txt          # Python dependencies
├── frontend/
│   ├── index.html               # Main HTML page
│   ├── style.css                # Styling
│   └── script.js                # JavaScript logic
├── samples/                      # Sample images folder (create this)
└── README.md                     # This file
```

## 🛠️ Technologies Used

### Backend

- **Python 3.8+**
- **TensorFlow 2.15**: Deep learning framework
- **Flask**: Web framework for REST API
- **Flask-CORS**: Cross-origin resource sharing
- **Pillow**: Image processing
- **NumPy**: Numerical computations

### Frontend

- **HTML5**: Structure
- **CSS3**: Styling with modern gradients and animations
- **JavaScript (ES6+)**: Interactive functionality
- **Fetch API**: REST API communication

### Models

- **Action Recognition**: MobileNetV2 (CNN) + Dense layers
- **Image Captioning**: InceptionV3 (CNN) + LSTM decoder

## 📦 Installation & Setup

### Prerequisites

- Python 3.8 or higher
- pip (Python package manager)
- Modern web browser (Chrome, Firefox, Edge)

### Step 1: Install Backend Dependencies

```bash
cd backend
pip install -r requirements.txt
```

**Note**: TensorFlow installation may take some time (500MB+). Make sure you have a stable internet connection.

### Step 2: Start the Backend Server

```bash
python app.py
```

The API server will start on `http://localhost:5000`

You should see:

```
Starting Action Recognition and Image Captioning API...
Loading models...
* Running on http://0.0.0.0:5000
```

### Step 3: Open the Frontend

1. Navigate to the `frontend` folder
2. Open `index.html` in your web browser
3. Or use VS Code Live Server extension

## 🚀 Usage

### Using the Web Interface

1. **Upload an Image**:

   - Click the upload area or drag and drop an image
   - Supported formats: JPG, PNG, JPEG (max 5MB)

2. **Analyze**:

   - Click the "Analyze Image" button
   - Wait for the AI models to process (few seconds)

3. **View Results**:
   - **Action Recognition**: Shows detected action with confidence score
   - **Image Caption**: Displays generated description

### Using the REST API

#### 1. Health Check

```bash
curl http://localhost:5000/api/health
```

#### 2. Recognize Action

```bash
curl -X POST -F "image=@path/to/image.jpg" http://localhost:5000/api/recognize-action
```

Response:

```json
{
  "success": true,
  "action": "WALKING",
  "confidence": 0.85,
  "all_predictions": [...]
}
```

#### 3. Generate Caption

```bash
curl -X POST -F "image=@path/to/image.jpg" http://localhost:5000/api/generate-caption
```

Response:

```json
{
  "success": true,
  "caption": "A person performing an activity"
}
```

## 🧠 Model Architecture

### Action Recognition (CNN + LSTM approach)

```
Input Image (224x224x3)
    ↓
MobileNetV2 (Pre-trained on ImageNet)
    ↓
Flatten
    ↓
Dense (512 units, ReLU)
    ↓
Dropout (0.5)
    ↓
Dense (256 units, ReLU)
    ↓
Dropout (0.3)
    ↓
Output (6 classes, Softmax)
```

### Image Captioning (CNN + LSTM)

```
Input Image (299x299x3)
    ↓
InceptionV3 (Feature Extractor)
    ↓
LSTM Decoder (generates caption word by word)
    ↓
Caption Text
```

## 📊 HAR Dataset

The system is designed to work with the **Human Activity Recognition (HAR)** dataset, which includes:

- **6 Activities**: Walking, Walking Upstairs, Walking Downstairs, Sitting, Standing, Laying
- **Lightweight**: Smaller dataset suitable for quick training
- **TensorFlow Integration**: Can be loaded directly using TensorFlow Datasets

### Loading HAR Dataset (for training)

```python
import tensorflow_datasets as tfds

# Load HAR dataset
dataset = tfds.load('har', split='train')
```

## 📸 Sample Images

Create a `samples` folder and add test images:

- Walking: Person walking on street
- Sitting: Person sitting on chair
- Standing: Person standing
- Other activities

## 🔧 Configuration

### Backend Configuration

Edit `app.py` to change:

- Port: `app.run(port=5000)`
- Debug mode: `app.run(debug=True)`
- Host: `app.run(host='0.0.0.0')`

### Frontend Configuration

Edit `script.js` to change:

- API URL: `const API_URL = 'http://localhost:5000'`

## 🐛 Troubleshooting

### Backend Issues

1. **TensorFlow Installation Error**:

   ```bash
   pip install tensorflow-cpu==2.15.0  # For CPU-only version
   ```

2. **CORS Error**:

   - Make sure Flask-CORS is installed
   - Check that CORS is enabled in `app.py`

3. **Model Loading Error**:
   - First run will download pre-trained models (~500MB)
   - Ensure stable internet connection

### Frontend Issues

1. **API Not Connected**:

   - Verify backend is running on port 5000
   - Check browser console for errors
   - Ensure API_URL is correct

2. **Image Upload Not Working**:
   - Check file size (max 5MB)
   - Verify file format (JPG, PNG, JPEG)

## 📚 API Documentation

### Endpoints

| Endpoint                | Method | Description                |
| ----------------------- | ------ | -------------------------- |
| `/`                     | GET    | API information            |
| `/api/health`           | GET    | Health check               |
| `/api/recognize-action` | POST   | Recognize action in image  |
| `/api/generate-caption` | POST   | Generate caption for image |

## 🎓 Educational Purpose

This project demonstrates:

- ✅ Deep Learning model integration
- ✅ CNN for image feature extraction
- ✅ LSTM for sequence generation
- ✅ REST API development
- ✅ Frontend-Backend communication
- ✅ Transfer learning with pre-trained models
- ✅ Real-time image processing

## 📝 Future Enhancements

- [ ] Video action recognition (sequence of frames)
- [ ] Real LSTM integration for captions
- [ ] Model training on custom datasets
- [ ] Batch processing
- [ ] Model fine-tuning
- [ ] Mobile app integration
- [ ] Real-time camera feed support

## 👨‍💻 Development

### Training Custom Models

To train with HAR dataset:

```python
# In action_recognition.py
model = ActionRecognitionModel()
model.train_with_har_dataset()
```

### Adding New Activities

Edit `action_recognition.py`:

```python
self.activity_labels = [
    'WALKING',
    'RUNNING',  # Add new activity
    'JUMPING',  # Add new activity
    # ...
]
```

## 🤝 GitHub Repository Setup

1. **Initialize Git**:

```bash
git init
git add .
git commit -m "Initial commit: Action Recognition & Image Captioning"
```

2. **Create GitHub Repository**:

- Go to GitHub.com
- Create new repository
- Follow instructions to push code

3. **Push to GitHub**:

```bash
git remote add origin <your-repo-url>
git branch -M main
git push -u origin main
```

## 📄 License

This project is for educational purposes as part of coursework assignment.

## 👤 Author

**Your Name**

- Course: Deep Learning
- Assignment: Action Recognition & Image Captioning
- Date: January 2026

## 📧 Contact

For queries, contact during lecture sessions or via email.

---

**Note**: This is a coursework project. Ensure you understand the code and can explain the process during the interview session.

## 🎯 Interview Preparation Tips

Be ready to explain:

1. ✅ CNN architecture and how it extracts features
2. ✅ LSTM architecture and its role in sequence processing
3. ✅ Transfer learning with MobileNetV2 and InceptionV3
4. ✅ REST API design and endpoints
5. ✅ Frontend-backend communication
6. ✅ Image preprocessing and normalization
7. ✅ Model evaluation metrics
8. ✅ Challenges faced and solutions

Good luck! 🚀
