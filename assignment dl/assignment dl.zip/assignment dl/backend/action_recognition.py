import tensorflow as tf
import numpy as np
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import Dense, LSTM, Dropout, Conv2D, MaxPooling2D, Flatten, TimeDistributed, Input
from tensorflow.keras.applications import MobileNetV2
from PIL import Image
import os

class ActionRecognitionModel:
    def __init__(self):
        self.img_size = (224, 224)
        self.num_classes = 6  # HAR dataset has 6 activities
        self.activity_labels = [
            'WALKING',
            'WALKING_UPSTAIRS', 
            'WALKING_DOWNSTAIRS',
            'SITTING',
            'STANDING',
            'LAYING'
        ]
        self.model = self.build_model()
        self.load_or_train_model()
    
    def build_model(self):
        """
        Build CNN+LSTM model for action recognition
        Using CNN for spatial features and LSTM for temporal features
        """
        # For single image, we'll use CNN with dense layers
        # In real scenario, you'd use sequence of frames with LSTM
        
        base_model = MobileNetV2(
            input_shape=(224, 224, 3),
            include_top=False,
            weights='imagenet'
        )
        
        # Freeze base model
        base_model.trainable = False
        
        model = Sequential([
            base_model,
            Flatten(),
            Dense(512, activation='relu'),
            Dropout(0.5),
            Dense(256, activation='relu'),
            Dropout(0.3),
            Dense(self.num_classes, activation='softmax')
        ])
        
        model.compile(
            optimizer='adam',
            loss='categorical_crossentropy',
            metrics=['accuracy']
        )
        
        return model
    
    def load_or_train_model(self):
        """Load pre-trained model or create a simple model"""
        model_path = 'action_recognition_model.h5'
        
        if os.path.exists(model_path):
            print("Loading saved action recognition model...")
            try:
                self.model = tf.keras.models.load_model(model_path)
                print("Model loaded successfully!")
            except:
                print("Could not load model, using fresh model")
        else:
            print("No saved model found. Using pre-trained base model.")
            print("For production, train the model with HAR dataset.")
    
    def preprocess_image(self, image):
        """Preprocess image for model input"""
        if image.mode != 'RGB':
            image = image.convert('RGB')
        
        # Resize image
        image = image.resize(self.img_size)
        
        # Convert to array and normalize
        img_array = tf.keras.preprocessing.image.img_to_array(image)
        img_array = tf.keras.applications.mobilenet_v2.preprocess_input(img_array)
        img_array = np.expand_dims(img_array, axis=0)
        
        return img_array
    
    def predict(self, image):
        """Predict action from image"""
        # Preprocess image
        processed_image = self.preprocess_image(image)
        
        # Make prediction
        predictions = self.model.predict(processed_image, verbose=0)
        predicted_class = np.argmax(predictions[0])
        confidence = predictions[0][predicted_class]
        
        # Get all predictions with confidence
        all_predictions = []
        for idx, prob in enumerate(predictions[0]):
            all_predictions.append({
                'action': self.activity_labels[idx],
                'confidence': float(prob)
            })
        
        # Sort by confidence
        all_predictions = sorted(all_predictions, key=lambda x: x['confidence'], reverse=True)
        
        return {
            'action': self.activity_labels[predicted_class],
            'confidence': confidence,
            'all_predictions': all_predictions
        }
    
    def train_with_har_dataset(self):
        """
        Train model with HAR dataset
        This is a placeholder - actual implementation would load HAR data
        """
        print("Training with HAR dataset...")
        print("Note: For actual training, you would:")
        print("1. Load HAR dataset using TensorFlow Datasets")
        print("2. Preprocess the data")
        print("3. Train the model")
        print("4. Save the trained model")
        
        # Example of loading HAR dataset (requires tensorflow-datasets)
        # import tensorflow_datasets as tfds
        # dataset = tfds.load('har', split='train')
        
        # For now, we'll use the pre-trained base model
        pass

if __name__ == "__main__":
    # Test the model
    model = ActionRecognitionModel()
    print("Action Recognition Model initialized successfully!")
    print(f"Number of classes: {model.num_classes}")
    print(f"Activity labels: {model.activity_labels}")
