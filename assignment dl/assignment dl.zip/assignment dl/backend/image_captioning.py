import tensorflow as tf
import numpy as np
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, LSTM, Embedding, Dropout, Add, Input
from tensorflow.keras.applications import InceptionV3
from tensorflow.keras.preprocessing.sequence import pad_sequences
from PIL import Image
import pickle
import os

class ImageCaptioningModel:
    def __init__(self):
        self.img_size = (299, 299)
        self.max_length = 34  # Maximum caption length
        self.vocab_size = 5000  # Vocabulary size
        
        # Build models
        self.encoder = self.build_encoder()
        self.model = None
        
        # Initialize tokenizer
        self.tokenizer = self.create_tokenizer()
        
        print("Image Captioning Model initialized")
    
    def build_encoder(self):
        """Build CNN encoder for image features"""
        base_model = InceptionV3(weights='imagenet')
        # Remove the last layer
        model = Model(inputs=base_model.input, 
                     outputs=base_model.layers[-2].output)
        return model
    
    def create_tokenizer(self):
        """Create a simple tokenizer"""
        # In production, this would be trained on a caption dataset
        # For now, we'll use a simple dictionary
        
        tokenizer_path = 'tokenizer.pkl'
        if os.path.exists(tokenizer_path):
            with open(tokenizer_path, 'rb') as f:
                tokenizer = pickle.load(f)
            return tokenizer
        
        # Create simple tokenizer
        from tensorflow.keras.preprocessing.text import Tokenizer
        
        # Sample captions for initialization
        sample_captions = [
            'a person walking on the street',
            'a man sitting on a chair',
            'a woman standing near a wall',
            'people walking in the park',
            'a person lying on the bed'
        ]
        
        tokenizer = Tokenizer(num_words=self.vocab_size, oov_token="<unk>")
        tokenizer.fit_on_texts(sample_captions)
        
        return tokenizer
    
    def build_decoder(self):
        """Build LSTM decoder for caption generation"""
        # Image feature input
        image_input = Input(shape=(2048,))
        image_dense = Dense(256, activation='relu')(image_input)
        
        # Sequence input
        seq_input = Input(shape=(self.max_length,))
        seq_embed = Embedding(self.vocab_size, 256, mask_zero=True)(seq_input)
        seq_lstm = LSTM(256)(seq_embed)
        
        # Merge inputs
        decoder = Add()([image_dense, seq_lstm])
        decoder = Dense(256, activation='relu')(decoder)
        output = Dense(self.vocab_size, activation='softmax')(decoder)
        
        model = Model(inputs=[image_input, seq_input], outputs=output)
        model.compile(loss='categorical_crossentropy', optimizer='adam')
        
        return model
    
    def preprocess_image(self, image):
        """Preprocess image for encoder"""
        if image.mode != 'RGB':
            image = image.convert('RGB')
        
        # Resize image
        image = image.resize(self.img_size)
        
        # Convert to array and preprocess
        img_array = tf.keras.preprocessing.image.img_to_array(image)
        img_array = np.expand_dims(img_array, axis=0)
        img_array = tf.keras.applications.inception_v3.preprocess_input(img_array)
        
        return img_array
    
    def extract_features(self, image):
        """Extract features from image using encoder"""
        processed_image = self.preprocess_image(image)
        features = self.encoder.predict(processed_image, verbose=0)
        return features
    
    def generate_caption_simple(self, image):
        """Generate caption using a rule-based approach for demo"""
        # Extract features
        features = self.extract_features(image)
        
        # For demo purposes, we'll use a simple template-based approach
        # In production, this would use a trained LSTM decoder
        
        # Analyze image features to determine content
        feature_sum = np.sum(features)
        feature_mean = np.mean(features)
        feature_std = np.std(features)
        
        # Simple heuristic-based captions
        templates = [
            "A person performing an activity",
            "An individual in motion",
            "Someone engaged in physical activity",
            "A person captured in action",
            "An active scene with movement"
        ]
        
        # Select template based on feature characteristics
        idx = int(abs(feature_mean * 100)) % len(templates)
        caption = templates[idx]
        
        return caption
    
    def predict(self, image):
        """Generate caption for image"""
        try:
            caption = self.generate_caption_simple(image)
            return caption
        except Exception as e:
            return f"A scene with activity (Error: {str(e)})"
    
    def train_with_dataset(self):
        """
        Train caption model with dataset
        This is a placeholder for actual training
        """
        print("Training caption model...")
        print("Note: For actual training, you would:")
        print("1. Load image captioning dataset (e.g., Flickr8k, COCO)")
        print("2. Extract features using CNN")
        print("3. Train LSTM decoder")
        print("4. Save the trained model")
        pass

if __name__ == "__main__":
    # Test the model
    model = ImageCaptioningModel()
    print("Image Captioning Model initialized successfully!")
