from flask import Flask, request, jsonify
from flask_cors import CORS
import tensorflow as tf
import numpy as np
from PIL import Image
import io
import base64
from action_recognition import ActionRecognitionModel
from image_captioning import ImageCaptioningModel

app = Flask(__name__)
CORS(app)

# Initialize models
action_model = ActionRecognitionModel()
caption_model = ImageCaptioningModel()

@app.route('/')
def home():
    return jsonify({
        'message': 'Action Recognition and Image Captioning API',
        'endpoints': {
            '/api/recognize-action': 'POST - Recognize action from image',
            '/api/generate-caption': 'POST - Generate caption for image',
            '/api/health': 'GET - Check API health'
        }
    })

@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({'status': 'healthy', 'message': 'API is running'})

@app.route('/api/recognize-action', methods=['POST'])
def recognize_action():
    try:
        if 'image' not in request.files:
            return jsonify({'error': 'No image file provided'}), 400
        
        file = request.files['image']
        if file.filename == '':
            return jsonify({'error': 'No selected file'}), 400
        
        # Read and preprocess image
        image_bytes = file.read()
        image = Image.open(io.BytesIO(image_bytes))
        
        # Perform action recognition
        result = action_model.predict(image)
        
        return jsonify({
            'success': True,
            'action': result['action'],
            'confidence': float(result['confidence']),
            'all_predictions': result['all_predictions']
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/generate-caption', methods=['POST'])
def generate_caption():
    try:
        if 'image' not in request.files:
            return jsonify({'error': 'No image file provided'}), 400
        
        file = request.files['image']
        if file.filename == '':
            return jsonify({'error': 'No selected file'}), 400
        
        # Read and preprocess image
        image_bytes = file.read()
        image = Image.open(io.BytesIO(image_bytes))
        
        # Generate caption
        caption = caption_model.predict(image)
        
        return jsonify({
            'success': True,
            'caption': caption
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    print("Starting Action Recognition and Image Captioning API...")
    print("Loading models...")
    app.run(debug=True, host='0.0.0.0', port=5000)
