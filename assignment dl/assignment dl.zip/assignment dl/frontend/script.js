// API Configuration
const API_URL = 'http://localhost:5000';

// DOM Elements
const uploadArea = document.getElementById('uploadArea');
const fileInput = document.getElementById('fileInput');
const previewImage = document.getElementById('previewImage');
const analyzeBtn = document.getElementById('analyzeBtn');
const resultsSection = document.getElementById('resultsSection');
const actionResult = document.getElementById('actionResult');
const captionResult = document.getElementById('captionResult');
const statusIndicator = document.getElementById('statusIndicator');
const statusText = document.getElementById('statusText');

let selectedFile = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    checkAPIStatus();
    setupEventListeners();
});

// Setup Event Listeners
function setupEventListeners() {
    // Upload area click
    uploadArea.addEventListener('click', () => {
        fileInput.click();
    });

    // File input change
    fileInput.addEventListener('change', handleFileSelect);

    // Drag and drop
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.classList.add('dragover');
    });

    uploadArea.addEventListener('dragleave', () => {
        uploadArea.classList.remove('dragover');
    });

    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleFile(files[0]);
        }
    });

    // Analyze button
    analyzeBtn.addEventListener('click', analyzeImage);

    // Sample buttons
    const sampleButtons = document.querySelectorAll('.sample-card .btn');
    sampleButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const card = e.target.closest('.sample-card');
            const action = card.dataset.action;
            showSampleInfo(action);
        });
    });
}

// Handle File Select
function handleFileSelect(e) {
    const file = e.target.files[0];
    if (file) {
        handleFile(file);
    }
}

function handleFile(file) {
    if (!file.type.startsWith('image/')) {
        alert('Please select an image file');
        return;
    }

    if (file.size > 5 * 1024 * 1024) {
        alert('File size should be less than 5MB');
        return;
    }

    selectedFile = file;

    // Show preview
    const reader = new FileReader();
    reader.onload = (e) => {
        previewImage.src = e.target.result;
        previewImage.classList.remove('hidden');
        uploadArea.querySelector('.upload-placeholder').style.display = 'none';
        analyzeBtn.classList.remove('hidden');
        resultsSection.classList.add('hidden');
    };
    reader.readAsDataURL(file);
}

// Analyze Image
async function analyzeImage() {
    if (!selectedFile) {
        alert('Please select an image first');
        return;
    }

    // Show results section
    resultsSection.classList.remove('hidden');
    actionResult.innerHTML = '<div class="loading">Analyzing action...</div>';
    captionResult.innerHTML = '<div class="loading">Generating caption...</div>';

    // Disable analyze button
    analyzeBtn.disabled = true;
    analyzeBtn.textContent = 'Analyzing...';

    try {
        // Analyze action and generate caption in parallel
        const [actionData, captionData] = await Promise.all([
            recognizeAction(selectedFile),
            generateCaption(selectedFile)
        ]);

        // Display results
        displayActionResult(actionData);
        displayCaptionResult(captionData);

    } catch (error) {
        console.error('Error:', error);
        actionResult.innerHTML = `<div class="error-message">Error: ${error.message}</div>`;
        captionResult.innerHTML = `<div class="error-message">Error: ${error.message}</div>`;
    } finally {
        analyzeBtn.disabled = false;
        analyzeBtn.textContent = 'Analyze Image';
    }
}

// Recognize Action
async function recognizeAction(file) {
    const formData = new FormData();
    formData.append('image', file);

    const response = await fetch(`${API_URL}/api/recognize-action`, {
        method: 'POST',
        body: formData
    });

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to recognize action');
    }

    return await response.json();
}

// Generate Caption
async function generateCaption(file) {
    const formData = new FormData();
    formData.append('image', file);

    const response = await fetch(`${API_URL}/api/generate-caption`, {
        method: 'POST',
        body: formData
    });

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to generate caption');
    }

    return await response.json();
}

// Display Action Result
function displayActionResult(data) {
    const confidence = (data.confidence * 100).toFixed(2);
    
    let html = `
        <div class="action-result">
            <div class="action-name">${data.action}</div>
            <div class="confidence">Confidence: ${confidence}%</div>
        </div>
    `;

    if (data.all_predictions && data.all_predictions.length > 0) {
        html += '<div class="predictions-list">';
        html += '<h3 style="margin-bottom: 10px; color: #374151;">All Predictions:</h3>';
        
        data.all_predictions.slice(0, 5).forEach(pred => {
            const conf = (pred.confidence * 100).toFixed(2);
            html += `
                <div class="prediction-item">
                    <span class="prediction-name">${pred.action}</span>
                    <span class="prediction-confidence">${conf}%</span>
                </div>
            `;
        });
        
        html += '</div>';
    }

    actionResult.innerHTML = html;
}

// Display Caption Result
function displayCaptionResult(data) {
    const html = `
        <div class="caption-text">
            "${data.caption}"
        </div>
    `;
    captionResult.innerHTML = html;
}

// Check API Status
async function checkAPIStatus() {
    try {
        const response = await fetch(`${API_URL}/api/health`);
        
        if (response.ok) {
            statusIndicator.classList.add('online');
            statusIndicator.classList.remove('offline');
            statusText.textContent = 'API Connected';
        } else {
            throw new Error('API not responding');
        }
    } catch (error) {
        statusIndicator.classList.add('offline');
        statusIndicator.classList.remove('online');
        statusText.textContent = 'API Offline - Please start the backend server';
        console.error('API Status Error:', error);
    }
}

// Show Sample Info
function showSampleInfo(action) {
    alert(`Sample Image: ${action.toUpperCase()}\n\nNote: This is a demo. Upload your own images for actual action recognition.\n\nTo use this sample, you would need actual sample images in a 'samples' folder.`);
}

// Refresh API status every 30 seconds
setInterval(checkAPIStatus, 30000);
