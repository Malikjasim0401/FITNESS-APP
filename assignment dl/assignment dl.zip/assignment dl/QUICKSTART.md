# Quick Start Guide

## 🚀 Getting Started in 5 Minutes

### Step 1: Install Dependencies (2-3 minutes)

Open PowerShell in the `backend` folder and run:

```powershell
cd backend
pip install -r requirements.txt
```

**Important**: TensorFlow is ~500MB and may take a few minutes to download.

### Step 2: Start Backend Server (30 seconds)

```powershell
python app.py
```

You should see:

```
Starting Action Recognition and Image Captioning API...
Loading models...
* Running on http://0.0.0.0:5000
```

✅ Keep this terminal window open!

### Step 3: Open Frontend (10 seconds)

1. Navigate to the `frontend` folder
2. Right-click on `index.html`
3. Open with your web browser

**OR** in VS Code:

- Install "Live Server" extension
- Right-click `index.html` → "Open with Live Server"

### Step 4: Test the Application (1 minute)

1. Upload any image (person walking, sitting, etc.)
2. Click "Analyze Image"
3. View the action recognition and caption results!

---

## 📝 What You Need to Know for Interview

### 1. CNN (Convolutional Neural Network)

- **Purpose**: Extracts visual features from images
- **Our Usage**: MobileNetV2 and InceptionV3 (pre-trained on ImageNet)
- **How it works**:
  - Convolution layers detect patterns (edges, shapes)
  - Pooling layers reduce dimensions
  - Fully connected layers for classification

### 2. LSTM (Long Short-Term Memory)

- **Purpose**: Processes sequences and temporal data
- **Our Usage**:
  - Image captioning: generates text word-by-word
  - Video action recognition: processes frame sequences
- **Advantage**: Remembers long-term dependencies

### 3. Transfer Learning

- Using pre-trained models (trained on millions of images)
- Fine-tuning for our specific task
- Saves time and computational resources

### 4. REST API Architecture

```
Frontend (HTML/JS)
    ↓ HTTP POST
Backend (Flask)
    ↓
CNN Model → Extract Features
    ↓
LSTM/Dense → Generate Output
    ↓ JSON Response
Frontend displays results
```

### 5. HAR Dataset

- **H**uman **A**ctivity **R**ecognition
- 6 activities: Walking, Walking Upstairs, Walking Downstairs, Sitting, Standing, Laying
- Lightweight and suitable for learning
- Can be loaded using TensorFlow Datasets

---

## 🔧 Common Commands

### Backend Commands

```powershell
# Install dependencies
pip install -r requirements.txt

# Start server
python app.py

# Train model (optional)
python train_model.py

# Test model directly
python action_recognition.py
```

### Frontend

- Just open `index.html` in browser
- Or use Live Server extension in VS Code

---

## 🐛 Quick Troubleshooting

### Problem: "Module not found" error

**Solution**:

```powershell
pip install tensorflow flask flask-cors pillow numpy
```

### Problem: "API Offline" message on frontend

**Solution**:

- Make sure backend is running on port 5000
- Check terminal for errors

### Problem: CORS error in browser console

**Solution**:

- Flask-CORS is already configured
- Make sure you installed all requirements

### Problem: TensorFlow installation fails

**Solution**:

```powershell
# Try CPU-only version
pip install tensorflow-cpu==2.15.0
```

---

## 📊 Project Structure Explained

```
assignment-dl/
│
├── backend/                    # Python Flask API
│   ├── app.py                 # Main API server (Flask routes)
│   ├── action_recognition.py  # CNN model for action recognition
│   ├── image_captioning.py    # CNN+LSTM for captions
│   ├── train_model.py         # Training script
│   └── requirements.txt       # Python packages
│
├── frontend/                   # Web Interface
│   ├── index.html            # Main page structure
│   ├── style.css             # Styling and layout
│   └── script.js             # API calls and interactions
│
├── README.md                  # Full documentation
├── QUICKSTART.md             # This file
└── .gitignore                # Git ignore rules
```

---

## 📚 Key Files Explained

### `app.py` - API Server

- Creates Flask web server
- Defines API endpoints (`/api/recognize-action`, `/api/generate-caption`)
- Handles image uploads
- Returns JSON responses

### `action_recognition.py` - Action Recognition

- Uses MobileNetV2 (CNN) for feature extraction
- Classifies images into 6 activity categories
- Returns action with confidence score

### `image_captioning.py` - Image Captioning

- Uses InceptionV3 (CNN) for image features
- Uses LSTM to generate text descriptions
- Returns natural language caption

### `script.js` - Frontend Logic

- Handles file uploads
- Makes API calls using Fetch API
- Displays results dynamically
- Checks API health status

---

## 🎯 For Your Interview

### Be Ready to Explain:

1. **Why CNN for images?**

   - CNNs are designed for spatial data
   - Convolution operations detect features
   - Translation invariance

2. **Why LSTM for captions?**

   - LSTMs handle sequential data
   - Can generate text word-by-word
   - Maintains context through memory cells

3. **Transfer Learning Benefits**

   - Faster training
   - Better accuracy with less data
   - Leverages pre-trained knowledge

4. **REST API Design**

   - Stateless communication
   - Standard HTTP methods (POST, GET)
   - JSON for data exchange
   - CORS for cross-origin requests

5. **Model Architecture**
   ```
   Input Image → CNN (Feature Extraction)
                  ↓
              Features Vector
                  ↓
              LSTM/Dense Layers
                  ↓
              Output (Classification/Caption)
   ```

---

## 📱 Testing Tips

### Test Images to Try:

- Person walking
- Person sitting on chair
- Person standing
- Sports activities
- Everyday actions

### Expected Behavior:

- **Fast response**: 1-3 seconds
- **Confidence scores**: Usually 40-95%
- **Multiple predictions**: Shows top 5 actions
- **Caption**: Descriptive sentence

---

## 🎓 Learning Resources

### Understanding CNN:

- Stanford CS231n (Convolutional Neural Networks)
- YouTube: "But what is a neural network?" by 3Blue1Brown

### Understanding LSTM:

- "Understanding LSTM Networks" by Christopher Olah
- YouTube: "LSTM Networks" by StatQuest

### TensorFlow/Keras:

- Official TensorFlow tutorials
- Keras documentation

---

## ✅ Pre-Interview Checklist

- [ ] Project runs successfully
- [ ] Can upload and analyze images
- [ ] Understand CNN architecture
- [ ] Understand LSTM architecture
- [ ] Know what transfer learning is
- [ ] Can explain REST API design
- [ ] Understand the code flow
- [ ] Can discuss HAR dataset
- [ ] Know the evaluation metrics
- [ ] Prepared to show demo

---

## 💡 Pro Tips

1. **Demo Preparation**: Test thoroughly before interview
2. **Understand Flow**: Know how data moves through system
3. **Know Limitations**: Discuss what could be improved
4. **Be Honest**: If something isn't working, explain why
5. **Show Learning**: Discuss what you learned building this

---

Good luck with your interview! 🚀

Remember: Understanding > Memorization
